#!/bin/bash
cd "$(dirname "$0")"
npm run format
echo "✅ Formatting complete!"

