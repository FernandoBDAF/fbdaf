import type { Metadata } from 'next'
import { ProjectsClient } from '@/components/projects/projects-client'
import { projects } from '@/lib/data/projects'

export const metadata: Metadata = {
  title: 'Projects - FernandoBDAF',
  description: 'Explore my portfolio of AI engineering and full-stack development projects.',
}

export function Projects() {
  return (
    <div className="min-h-screen py-16">
      <div className="container mx-auto px-4">
        <div className="mx-auto max-w-6xl space-y-12">
          {/* Page Header */}
          <div className="space-y-4 text-center">
            <h1 className="text-4xl font-bold text-text-primary md:text-5xl">Projects</h1>
            <p className="mx-auto max-w-2xl text-balance text-lg text-text-muted">A collection of projects showcasing my work in AI engineering, automation, and full-stack development</p>
          </div>

          {/* Projects with Filtering */}
          <ProjectsClient projects={projects} />
        </div>
      </div>
    </div>
  )
}
