"use client"

import Link from "next/link"
import { blogPosts } from "@/lib/data/blog"
import { Badge } from "@/components/ui/badge"
import { Card } from "@/components/ui/card"
import { Calendar, Clock } from "lucide-react"
import { trackEvent } from "@/lib/tracking"
import ComingSoon from "@/components/ui/coming-soon"

export default function BlogClientPage() {
  if (blogPosts.length === 0) {
    return <ComingSoon />
  }

  return (
    <main className="min-h-screen bg-background py-16 md:py-24">
      <div className="container mx-auto px-4 max-w-4xl">
        {/* Header */}
        <div className="mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">Blog</h1>
          <p className="text-lg text-muted-foreground">
            Thoughts on AI engineering, full-stack development, and building production software.
          </p>
        </div>

        {/* Blog Posts List */}
        <div className="space-y-6">
          {blogPosts.map((post) => (
            <Link
              key={post.slug}
              href={`/blog/${post.slug}`}
              onClick={() => trackEvent({ event: "blog_post_click", post: post.slug })}
            >
              <Card className="p-6 hover:border-accent transition-all duration-300 group">
                <h2 className="text-2xl font-bold text-foreground mb-2 group-hover:text-accent transition-colors">
                  {post.title}
                </h2>

                {/* Meta Info */}
                <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground mb-3">
                  <span className="flex items-center gap-1.5">
                    <Calendar className="h-4 w-4" />
                    {new Date(post.date).toLocaleDateString("en-US", {
                      year: "numeric",
                      month: "long",
                      day: "numeric",
                    })}
                  </span>
                  {post.readTime && (
                    <span className="flex items-center gap-1.5">
                      <Clock className="h-4 w-4" />
                      {post.readTime}
                    </span>
                  )}
                </div>

                <p className="text-muted-foreground mb-4">{post.description}</p>

                {/* Tags */}
                <div className="flex flex-wrap gap-2">
                  {post.tags.map((tag) => (
                    <Badge key={tag} variant="secondary">
                      {tag}
                    </Badge>
                  ))}
                </div>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </main>
  )
}
